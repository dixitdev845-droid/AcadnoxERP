# Acadnox ERP – Android Studio project

1. Install Android Studio (latest).
2. Open this `AcadnoxERP` folder in Android Studio.
3. Let Gradle sync finish; install Android SDK Platform 34 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The app UI is `app/src/main/assets/index.html` and runs in a WebView.
Data is stored locally on the device.

Demo logins:
- Admin: `admin` / `admin123`
- Faculty: `faculty` / `faculty123`
- Student: `CS001` / `student123`

These are demo credentials only. Change authentication and storage before real deployment.
